import React from "react";
import { Link } from "react-router-dom";

const PublicSidebar = () => (
  <div className="w-64 h-screen bg-gray-100 p-4">
    <h2 className="text-xl font-bold mb-4">Categories</h2>
    <ul>
      <li>
        <Link to="/">Restaurant</Link>
      </li>
      <li>
        <Link to="/">Grocery</Link>
      </li>
      <li>
        <Link to="/">Electronics</Link>
      </li>
      <li>
        <Link to="/">Books</Link>
      </li>
    </ul>
  </div>
);

export default PublicSidebar;
